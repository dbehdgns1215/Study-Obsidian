package com.ssafy.exam.listener;


import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class MyContextListener implements ServletContextListener {

	//Q1-1. 프로젝트 실행을 위해 아래 코드를 확인하여 완성하세요.
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("contextInitialized() called");
    }

    //Q1-2. 프로젝트 실행을 위해 아래 코드를 확인하여 완성하세요.
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("contextDestroyed() called");
    }

}




