package com.ssafy.exam.model.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ssafy.exam.model.dto.Member;
import com.ssafy.exam.model.dto.Music;

public class FileMusicDao implements MusicDao {
	private final File memberDataFile, musicDataFile;
	private List<Member> members;
	private List<Music> musicList;
	
	private FileMusicDao() {
		String path = FileMusicDao.class.getResource("/").getPath() + "member.dat";
		memberDataFile = new File(path);
		path = FileMusicDao.class.getResource("/").getPath() + "music.dat";
		musicDataFile = new File(path);

		try {
			if (!memberDataFile.exists()) {
				memberDataFile.createNewFile();
			}
			if (!musicDataFile.exists()) {
				musicDataFile.createNewFile();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
    //Q1-3. 프로젝트 실행을 위해 아래 코드를 확인하여 완성하세요.	
	public void load() {
		try (ObjectInputStream memOis = new ObjectInputStream(new FileInputStream(memberDataFile));
				ObjectInputStream musicOis = new ObjectInputStream(new FileInputStream(musicDataFile))) {
			members = (List) memOis.readObject();
			musicList = (List) musicOis.readObject();

			System.out.println("회원 정보 로딩 완료: " + members.size() + "명");
			System.out.println("음악 정보 로딩 완료:" + musicList.size() + "개");
		} catch (Exception e) {
			System.out.println("저장된 정보가 없습니다.");
			members = Collections.synchronizedList(new ArrayList<>());
			musicList = Collections.synchronizedList(new ArrayList<>());
		}
	}

	public void save() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(memberDataFile));
				ObjectOutputStream musicOos = new ObjectOutputStream(new FileOutputStream(musicDataFile))) {
			oos.writeObject(members);
			System.out.println("회원 정보 저장 완료");
			musicOos.writeObject(musicList);
			System.out.println("음악 정보 저장 완료");
		} catch (Exception e) {
			throw new RuntimeException("정보 저장 실패", e);
		}
	}

	public void reset(Connection con) {
		synchronized (members) {
			int length = 10;
			members.clear();
			for (int i = 0; i < length; i++) {
				members.add(new Member(i, "테스트" + (length - i), "test" + i + "@ssafy.com", "1234", "USER"));
			}
			members.add(new Member(100, "관리자", "admin@ssafy.com", "1234", "ADMIN"));
			System.out.println("멤버 초기화 완료 " + members.size() + " :" + members.get(0));
		}
	}

	public void musicReset(Connection con) {
		synchronized (musicList) {
			musicList.clear();
			musicList.add(new Music("song-1", "밤편지",2017, "아이유", "발라드"));
			musicList.add(new Music("song-2", "Golden", 2025, "HUNTR/X", "케이팝"));
			musicList.add(new Music("song-3", "BORN HATER", 2014, "애픽하이", "힙합"));
			System.out.println("음악 정보 초기화 완료 " + musicList.size() + " :" + musicList.get(0));
		}
	}

	@Override
	public List<Music> selectAll(Connection conn) {
		
		return musicList;
	}


	@Override
	public int insert(Connection conn, Music music) {
		// TODO Auto-generated method stub
		return 0;
	}



}
