package com.ssafy.exam.model.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.exam.model.dto.Music;


public interface MusicDao {

    /*등록 된 모든 정보 조회*/
	List<Music> selectAll(Connection conn);

	/*정보 등록*/
	int insert(Connection conn, Music music);


}
