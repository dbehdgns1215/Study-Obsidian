package com.ssafy.exam.model.dto;

import java.io.Serializable;

public class Music implements Serializable {
	private String code;
	private String title;
	private int releaseYear;
	private String artist;
	private String genre;
	
	public Music() {
		// TODO Auto-generated constructor stub
	}
	
	public Music(String code, String title, int releaseYear, String artist, String genre) {
		super();
		this.code = code;
		this.title = title;
		this.releaseYear = releaseYear;
		this.artist = artist;
		this.genre = genre;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	@Override
	public String toString() {
		return "Music [code=" + code + ", title=" + title + ", releaseYear=" + releaseYear + ", artist=" + artist
				+ ", genre=" + genre + "]";
	}
	

}
