package com.ssafy.exam.model.service;

import java.util.List;

import com.ssafy.exam.model.dto.Music;

public interface MusicService {

	List<Music> selectAll();

	int insert(Music music);


    
}
