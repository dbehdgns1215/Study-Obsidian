package com.ssafy.board.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.ssafy.board.model.BoardDto;
import com.ssafy.board.model.service.BoardServiceImpl;

@WebServlet("/article")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		System.out.println("action ===== " + action);
		
		String path = "/index.jsp";
		if("mvwrite".equals(action)) {
			path = "/board/write.jsp";
			response.sendRedirect(request.getContextPath() + path);
		} else if("write".equals(action)) {
			path = write(request, response);
//			forward(request, response, path);
			sendRedirect(request, response, path);
		}  else if("list".equals(action)) {
			path = list(request, response);
			forward(request, response, path);
		}  else if("view".equals(action)) {
			path = view(request, response);
			forward(request, response, path);
		} else {
			response.sendRedirect(request.getContextPath() + path);
		}
	}

	private String view(HttpServletRequest request, HttpServletResponse response) {
		int no = Integer.parseInt(request.getParameter("no"));
		try {
			BoardDto boardDto = BoardServiceImpl.getInstance().getArticle(no);
			request.setAttribute("article", boardDto);
			return "/board/view.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			return "/error/error.jsp";
		}
		
	}

	private String list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<BoardDto> list = BoardServiceImpl.getInstance().listArticle();
			System.out.println("list size: " + list.size());
			request.setAttribute("articles", list);
			return "/board/list.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			return "/error/error.jsp";
		}
		
	}

	private String write(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		BoardDto boardDto = new BoardDto();
		boardDto.setUserid(request.getParameter("userid"));
		boardDto.setSubject(request.getParameter("subject"));
		boardDto.setContent(request.getParameter("content"));
		try {
			BoardServiceImpl.getInstance().writeArticle(boardDto);
			return "/article?action=list";
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}
	
	private void sendRedirect(HttpServletRequest request, HttpServletResponse response, String path) throws IOException {
		response.sendRedirect(request.getContextPath() + path);
	}
	
	private void forward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

}
