package com.ssafy.board.model.service;

import java.util.List;

import com.ssafy.board.model.BoardDto;
import com.ssafy.board.model.dao.BoardDao;
import com.ssafy.board.model.dao.BoardDaoImpl;

public class BoardServiceImpl implements BoardService {

	private static BoardService instance = new BoardServiceImpl();
	
	private BoardDao boardDao;
	
	private BoardServiceImpl() {
		boardDao = BoardDaoImpl.getInstance();
	}
	
	public static BoardService getInstance() {
		return instance;
	}
	
	@Override
	public void writeArticle(BoardDto boardDto) throws Exception {
		boardDao.writeArticle(boardDto);
	}

	@Override
	public List<BoardDto> listArticle() throws Exception {
		return boardDao.listArticle();
	}

	@Override
	public BoardDto getArticle(int articleNo) throws Exception {
		BoardDto boardDto = boardDao.getArticle(articleNo); // hit dto: 0 db : 0
		if(boardDto != null) {
			boardDao.updateHit(articleNo); // dto : 0 db : 1
			boardDto.setHit(boardDto.getHit() + 1); // 1
		}
		return boardDto;
	}

	@Override
	public void modifyArticle(BoardDto boardDto) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteArticle(int articleNo) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
