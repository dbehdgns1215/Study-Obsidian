package com.ssafy.member.model.dao;

import java.sql.SQLException;

import com.ssafy.member.model.MemberDto;

public interface MemberDao {

	void joinMember(MemberDto memberDto) throws SQLException;
	MemberDto loginMember(String id, String pass) throws SQLException;
	
}
