package com.ssafy.member.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.member.model.MemberDto;
import com.ssafy.util.DbUtil;

public class MemberDaoImpl implements MemberDao {
	
	private static MemberDao instance = new MemberDaoImpl();
	
	private MemberDaoImpl() {}

	public static MemberDao getInstance() {
		return instance;
	}

	@Override
	public void joinMember(MemberDto memberDto) throws SQLException {

	}

	@Override
	public MemberDto loginMember(String id, String pass) throws SQLException {
		MemberDto memberDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DbUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select user_name, email_id, email_domain \n");
			sql.append("from members \n");
			sql.append("where user_id = ? and user_password = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pass);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				memberDto = new MemberDto();
				memberDto.setUserName(rs.getString("user_name"));
				memberDto.setEmailId(rs.getString("email_id"));
				memberDto.setEmailDomain(rs.getString("email_domain"));
			}
		} finally {
			DbUtil.close(rs, pstmt, conn);
		}
		return memberDto;
	}

}
