package com.ssafy.member.model.service;

import com.ssafy.member.model.MemberDto;
import com.ssafy.member.model.dao.MemberDao;
import com.ssafy.member.model.dao.MemberDaoImpl;

public class MemberServiceImpl implements MemberService {

	private static MemberService instance = new MemberServiceImpl();
	
	private final MemberDao memberDao = MemberDaoImpl.getInstance();
	
	private MemberServiceImpl() {}

	public static MemberService getInstance() {
		return instance;
	}

	@Override
	public void joinMember(MemberDto memberDto) throws Exception {
		
	}

	@Override
	public MemberDto loginMember(String id, String pass) throws Exception {
		return memberDao.loginMember(id, pass);
	}
	
}
