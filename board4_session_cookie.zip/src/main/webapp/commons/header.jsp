<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="root" value="${pageContext.request.contextPath}"></c:set>
<!DOCTYPE html>
<html lang="ko">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr"
      crossorigin="anonymous"
    />
    <link href="${root}/assets/css/app.css" rel="stylesheet" />
    <title>HISSAM</title>
  </head>
  <body>
  	<div>
  		<c:if test="${!empty userInfo}">
  			<span><b>${userInfo.userName}</b>님 안녕하세요</span>
  			<span><a href="${root}/member?action=logout">로그아웃</a></span>
  		</c:if>
  		<c:if test="${empty userInfo}">
  			<span><a href="${root}/member?action=mvlogin">로그인</a></span>
  			<span><a href="${root}/article?action=list">목록보기</a></span>
  		</c:if>
  	</div>