<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="/commons/header.jsp" %>
    <div class="container text-center">
      <h3>게시판 - Session & Cookie</h3>
      <c:if test="${empty userInfo}">
	      <a href="${root}/member?action=mvjoin">회원가입</a><br />
	      <a href="${root}/member?action=mvlogin">로그인</a>
      </c:if>
      <c:if test="${!empty userInfo}">
	      <a href="${root}/article?action=mvwrite">글쓰기</a><br />
	      <a href="${root}/article?action=list">글목록</a>
      </c:if>
    </div>
<%@ include file="/commons/footer.jsp" %>