<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/commons/header.jsp" %>
<%-- <%
String svid = "";
String ckid = "";
Cookie cookie[] = request.getCookies();
if(cookie != null) {
	for(Cookie cookie : cookies) {
		if("rememberme".equals(cookie.getName())) {
			svid = cookie.getValue();
			ckid = "checked";
			break;
		}
	}
}
%> --%>
<c:if test="${!empty cookie.rememberme.value}">
	<c:set var="svid" value="${cookie.rememberme.value}"/>
	<c:set var="ckid" value=" checked"/>
</c:if>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10 col-sm-12">
          <h2 class="my-3 py-3 shadow-sm bg-light text-center">
            <mark class="orange">로그인</mark>
          </h2>
        </div>
        <div class="col-lg-8 col-md-10 col-sm-12">
          <form id="form-login" method="POST" action="">
          	<input type="hidden" name="action" value="login" />
            <div class="form-check mb-3 float-end">
              <input
                class="form-check-input"
                type="checkbox"
                value="rememberme"
                id="saveid"
                name="saveid"
                ${ckid}
              />
              <label class="form-check-label" for="saveid"> 아이디저장 </label>
            </div>
            <div class="mb-3">
              <label for="userid" class="form-label">아이디 : </label>
              <input
                type="text"
                class="form-control"
                id="userid"
                name="userid"
                placeholder="아이디..."
                value="${svid}"
              />
            </div>
            <div class="mb-3">
              <label for="userpwd" class="form-label">비밀번호 : </label>
              <input
                type="password"
                class="form-control"
                id="userpwd"
                name="userpwd"
                placeholder="비밀번호..."
              />
            </div>
            <c:if test="${msg != null}">
            	<div class="alert alert-danger" role="alert">
				  ${msg}
				</div>
            </c:if>
            <div class="col-auto text-center">
              <button type="button" id="btn-login" class="btn btn-outline-primary mb-3">
                로그인
              </button>
              <button type="button" class="btn btn-outline-success mb-3">회원가입</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
      crossorigin="anonymous"
    ></script>
    <script>
      document.querySelector("#btn-login").addEventListener("click", function () {
        if (!document.querySelector("#userid").value) {
          alert("아이디 입력!!");
          return;
        } else if (!document.querySelector("#userpwd").value) {
          alert("비밀번호 입력!!");
          return;
        } else {
          let form = document.querySelector("#form-login");
          form.setAttribute("action", "${root}/member");
          form.submit();
        }
      });
    </script>
<%@ include file="/commons/footer.jsp" %>
